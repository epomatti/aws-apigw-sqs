print("fake")
